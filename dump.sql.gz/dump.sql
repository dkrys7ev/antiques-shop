-- MySQL dump 10.13  Distrib 8.0.22, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: antique_shop
-- ------------------------------------------------------
-- Server version	8.0.22

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `orders`
--

DROP TABLE IF EXISTS `orders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `orders` (
  `ID` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint NOT NULL,
  `date_created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `products` longtext NOT NULL,
  `total` float NOT NULL,
  `status` varchar(50) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `orders`
--

LOCK TABLES `orders` WRITE;
/*!40000 ALTER TABLE `orders` DISABLE KEYS */;
/*!40000 ALTER TABLE `orders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `products`
--

DROP TABLE IF EXISTS `products`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `products` (
  `ID` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint NOT NULL,
  `title` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `description` text CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `categories` longtext CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `images` longtext CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `price` float NOT NULL,
  `status` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `products`
--

LOCK TABLES `products` WRITE;
/*!40000 ALTER TABLE `products` DISABLE KEYS */;
INSERT INTO `products` VALUES (2,1,'1937 Continental 340 Typewriter','Rare Continental 340 Typewriter - Early Edition from 1937 - A remarkable portable typewriter. The typewriter is working but service is needed.','a:2:{i:0;s:10:\"historical\";i:1;s:5:\"other\";}','a:8:{i:0;s:39:\"1624798886_il_794xN.2117507587_75hn.jpg\";i:1;s:39:\"1624798886_il_794xN.2069937068_lwor.jpg\";i:2;s:39:\"1624798886_il_794xN.2069937074_5xmm.jpg\";i:3;s:39:\"1624798886_il_794xN.2117507187_th40.jpg\";i:4;s:39:\"1624798886_il_794xN.2117507197_yzzr.jpg\";i:5;s:39:\"1624798886_il_794xN.2117507203_79pm.jpg\";i:6;s:39:\"1624798886_il_794xN.2069934288_abk0.jpg\";i:7;s:40:\"1624798886_il_1140xN.2069937076_cu55.jpg\";}',299.99,'active'),(3,1,'Mechanical Pocket Watch','Case Material: AlloyDiameter: About 4.9cmThickness: About 1.7cmTotal Length of Chain: About 80cm','a:1:{i:0;s:8:\"everyday\";}','a:4:{i:0;s:21:\"1624799146_watch1.png\";i:1;s:21:\"1624799146_watch2.png\";i:2;s:21:\"1624799146_watch3.png\";i:3;s:21:\"1624799146_watch4.png\";}',39.99,'active'),(4,1,'&amp;#34;Decor Splendor&amp;#34; Art Deco Green Bakelite Lamps (pair)','These are rare (a word I hesitate to use, though not in this instance).  Note the marbled green bakelite, so splendid in beauty and character that they take your breath away.  Tapered form...1/2&amp;#34; at the bottom of the stem to 1&amp;#34; at the top.  Two original matching green bakelite speed rings.  An original and seldom seen design for bakelite lamps.','a:1:{i:0;s:8:\"everyday\";}','a:3:{i:0;s:20:\"1624799411_lamp1.jpg\";i:1;s:20:\"1624799411_lamp2.jpg\";i:2;s:20:\"1624799411_lamp3.jpg\";}',899,'active'),(5,1,'Vintage 1960&amp;#39;s Woody Woodpecker Mug','A Vintage 1960&amp;#39;s Woody Woodpecker Plastic Cup Mug F&amp;F Walter Lantz Dayton Ohio','a:1:{i:0;s:8:\"everyday\";}','a:4:{i:0;s:19:\"1624799874_cup3.jpg\";i:1;s:19:\"1624799874_cup4.jpg\";i:2;s:19:\"1624799874_cup5.jpg\";i:3;s:19:\"1624799874_cup6.jpg\";}',74.99,'active'),(6,1,'1971 Topps Hank Aaron Atlanta Braves #400 Baseball Card','Milwaukee and Atlanta Braves fans seeking a striking, top-class collectible need look no further than the 1971 Hank Aaron Atlanta Braves number 400 baseball card, issued by Topps.','a:2:{i:0;s:10:\"historical\";i:1;s:5:\"other\";}','a:2:{i:0;s:20:\"1624800012_card1.jpg\";i:1;s:20:\"1624800012_card2.jpg\";}',3890,'active'),(7,1,'Vintage Military Watch','ROLEX / PANERAI 6152/1 Spectacular Vintage Historic Military Watch W/ ROLEX MVT','a:1:{i:0;s:10:\"historical\";}','a:4:{i:0;s:21:\"1624800333_watch0.jpg\";i:1;s:21:\"1624800333_watch2.jpg\";i:2;s:21:\"1624800333_watch3.jpg\";i:3;s:21:\"1624800333_watch4.jpg\";}',1499,'active');
/*!40000 ALTER TABLE `products` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `ID` bigint unsigned NOT NULL AUTO_INCREMENT,
  `email` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `password` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'dkrystev@gmail.com','4b5cafe2b406214e51bb6d0e8eff9ae1','Danislav Krastev');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-06-27 17:01:37

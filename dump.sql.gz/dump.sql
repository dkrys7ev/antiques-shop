-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Jul 05, 2021 at 02:41 PM
-- Server version: 8.0.22
-- PHP Version: 7.4.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `antique_shop`
--

-- --------------------------------------------------------

--
-- Table structure for table `cart_items`
--

CREATE TABLE `cart_items` (
  `ID` bigint UNSIGNED NOT NULL,
  `user_id` bigint NOT NULL,
  `product_id` bigint NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `cart_items`
--

INSERT INTO `cart_items` (`ID`, `user_id`, `product_id`) VALUES
(30, 1, 7);

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `ID` bigint UNSIGNED NOT NULL,
  `user_id` bigint NOT NULL,
  `date_created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `products` longtext NOT NULL,
  `total` float NOT NULL,
  `status` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `ID` bigint UNSIGNED NOT NULL,
  `user_id` bigint NOT NULL,
  `title` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `description` text CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `categories` longtext CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `images` longtext CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `price` float NOT NULL,
  `status` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`ID`, `user_id`, `title`, `description`, `categories`, `images`, `price`, `status`) VALUES
(2, 1, '1937 Continental 340 Typewriter', 'Rare Continental 340 Typewriter - Early Edition from 1937 - A remarkable portable typewriter. The typewriter is working but service is needed.', 'a:2:{i:0;s:10:\"historical\";i:1;s:5:\"other\";}', 'a:8:{i:0;s:39:\"1624798886_il_794xN.2117507587_75hn.jpg\";i:1;s:39:\"1624798886_il_794xN.2069937068_lwor.jpg\";i:2;s:39:\"1624798886_il_794xN.2069937074_5xmm.jpg\";i:3;s:39:\"1624798886_il_794xN.2117507187_th40.jpg\";i:4;s:39:\"1624798886_il_794xN.2117507197_yzzr.jpg\";i:5;s:39:\"1624798886_il_794xN.2117507203_79pm.jpg\";i:6;s:39:\"1624798886_il_794xN.2069934288_abk0.jpg\";i:7;s:40:\"1624798886_il_1140xN.2069937076_cu55.jpg\";}', 299.99, 'active'),
(3, 1, 'Mechanical Pocket Watch', 'Case Material: Alloy\r\nDiameter: About 4.9cm\r\nThickness: About 1.7cm\r\nTotal Length of Chain: About 80cm', 'a:1:{i:0;s:8:\"everyday\";}', 'a:4:{i:0;s:21:\"1624799146_watch1.png\";i:1;s:21:\"1624799146_watch2.png\";i:2;s:21:\"1624799146_watch3.png\";i:3;s:21:\"1624799146_watch4.png\";}', 39.99, 'active'),
(4, 1, '&amp;#34;Decor Splendor&amp;#34; Art Deco Green Bakelite Lamps (pair)', 'These are rare (a word I hesitate to use, though not in this instance).  Note the marbled green bakelite, so splendid in beauty and character that they take your breath away.  Tapered form...1/2&amp;#34; at the bottom of the stem to 1&amp;#34; at the top.  Two original matching green bakelite speed rings.  An original and seldom seen design for bakelite lamps.', 'a:1:{i:0;s:8:\"everyday\";}', 'a:3:{i:0;s:20:\"1624799411_lamp1.jpg\";i:1;s:20:\"1624799411_lamp2.jpg\";i:2;s:20:\"1624799411_lamp3.jpg\";}', 899, 'active'),
(5, 1, 'Vintage 1960&amp;#39;s Woody Woodpecker Mug', 'A Vintage 1960&amp;#39;s Woody Woodpecker Plastic Cup Mug F&amp;F Walter Lantz Dayton Ohio', 'a:1:{i:0;s:8:\"everyday\";}', 'a:4:{i:0;s:19:\"1624799874_cup3.jpg\";i:1;s:19:\"1624799874_cup4.jpg\";i:2;s:19:\"1624799874_cup5.jpg\";i:3;s:19:\"1624799874_cup6.jpg\";}', 74.99, 'active'),
(6, 1, '1971 Topps Hank Aaron Atlanta Braves #400 Baseball Card', 'Milwaukee and Atlanta Braves fans seeking a striking, top-class collectible need look no further than the 1971 Hank Aaron Atlanta Braves number 400 baseball card, issued by Topps.', 'a:2:{i:0;s:10:\"historical\";i:1;s:5:\"other\";}', 'a:2:{i:0;s:20:\"1624800012_card1.jpg\";i:1;s:20:\"1624800012_card2.jpg\";}', 3890, 'active'),
(7, 1, 'Vintage Military Watch', 'ROLEX / PANERAI 6152/1 Spectacular Vintage Historic Military Watch W/ ROLEX MVT', 'a:1:{i:0;s:10:\"historical\";}', 'a:4:{i:0;s:21:\"1624800333_watch0.jpg\";i:1;s:21:\"1624800333_watch2.jpg\";i:2;s:21:\"1624800333_watch3.jpg\";i:3;s:21:\"1624800333_watch4.jpg\";}', 1499, 'cart');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `ID` bigint UNSIGNED NOT NULL,
  `email` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `password` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`ID`, `email`, `password`, `name`) VALUES
(1, 'dkrystev@gmail.com', '4b5cafe2b406214e51bb6d0e8eff9ae1', 'Danislav Krastev');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `cart_items`
--
ALTER TABLE `cart_items`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`ID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `cart_items`
--
ALTER TABLE `cart_items`
  MODIFY `ID` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `ID` bigint UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `ID` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `ID` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
